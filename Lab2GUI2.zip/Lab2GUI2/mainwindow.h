#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include "iconizedlineedit.h"
#include "ledindicator.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    // Задание 1+2: Login
    void onLoginClicked();

    // Задание 3: Изображение
    void onChooseFile();
    void onLoadImage();

    // Задание 4: LED
    void onLedStateChanged(LedIndicator::State state);

private:
    // Задание 1+2
    IconizedLineEdit *m_userField;
    IconizedLineEdit *m_passField;
    QLabel           *m_loginStatus;

    // Задание 3
    IconizedLineEdit *m_pathField;
    QLabel           *m_imageLabel;

    // Задание 4
    LedIndicator *m_led;
    QLabel       *m_ledStatus;

    QWidget *buildLoginTab();
    QWidget *buildImageTab();
    QWidget *buildLedTab();
};

#endif
