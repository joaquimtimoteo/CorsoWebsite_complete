#include "iconizedlineedit.h"
#include <QMouseEvent>

// ── Подкласс QLabel с поддержкой клика ──────────
class ClickableLabel : public QLabel
{
    Q_OBJECT
public:
    explicit ClickableLabel(QWidget *parent = nullptr)
        : QLabel(parent)
    {
        setCursor(Qt::PointingHandCursor);
    }
signals:
    void clicked();
protected:
    void mousePressEvent(QMouseEvent *) override
    {
        emit clicked();
    }
};

#include "iconizedlineedit.moc"

// ════════════════════════════════════════════════
//  КОНСТРУКТОР
// ════════════════════════════════════════════════
IconizedLineEdit::IconizedLineEdit(QWidget *parent)
    : QWidget(parent)
    , m_mode(ModeValidation)
{
    m_layout = new QHBoxLayout(this);
    m_layout->setContentsMargins(2, 2, 2, 2);
    m_layout->setSpacing(4);

    auto *icon  = new ClickableLabel(this);
    m_iconLabel = icon;
    m_iconLabel->setFixedSize(28, 28);
    m_iconLabel->setAlignment(Qt::AlignCenter);
    m_iconLabel->setText("🔴");
    m_iconLabel->setStyleSheet("font-size:16px;");

    m_lineEdit = new QLineEdit(this);

    m_layout->addWidget(m_iconLabel);
    m_layout->addWidget(m_lineEdit);
    setLayout(m_layout);

    connect(icon, &ClickableLabel::clicked,
            this, &IconizedLineEdit::onIconClicked);
    connect(m_lineEdit, &QLineEdit::textChanged,
            this,       &IconizedLineEdit::onTextChanged);
}

// ── Getters / Setters ────────────────────────────
QString IconizedLineEdit::text() const
{
    return m_lineEdit->text();
}

void IconizedLineEdit::setText(const QString &text)
{
    m_lineEdit->setText(text);
}

void IconizedLineEdit::setPlaceholderText(const QString &text)
{
    m_lineEdit->setPlaceholderText(text);
}

void IconizedLineEdit::setEchoMode(QLineEdit::EchoMode mode)
{
    m_lineEdit->setEchoMode(mode);
}

void IconizedLineEdit::setValidator(const QValidator *v)
{
    m_lineEdit->setValidator(v);
}

void IconizedLineEdit::setIconMode(IconMode mode)
{
    m_mode = mode;
    if (mode == ModeFile) {
        m_iconLabel->setText("📂");
        m_iconLabel->setToolTip("Нажмите для выбора файла");
    }
}

void IconizedLineEdit::setStaticIcon(const QString &icon)
{
    m_mode = ModeStatic;
    m_iconLabel->setText(icon);
}

// ── Слоты ───────────────────────────────────────
void IconizedLineEdit::onTextChanged(const QString &text)
{
    if (m_mode == ModeValidation)
        updateIcon(text);
    emit textChanged(text);
}

void IconizedLineEdit::onIconClicked()
{
    emit iconClicked();
}

// ── Обновление иконки ───────────────────────────
void IconizedLineEdit::updateIcon(const QString &text)
{
    const QValidator *v = m_lineEdit->validator();

    if (text.isEmpty()) {
        m_iconLabel->setText("🔴");
        return;
    }

    if (v) {
        int pos = 0;
        QString t = text;
        if (v->validate(t, pos) == QValidator::Acceptable)
            m_iconLabel->setText("✅");
        else
            m_iconLabel->setText("⚠️");
    } else {
        m_iconLabel->setText("✅");
    }
}
