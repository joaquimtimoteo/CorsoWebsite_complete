#include "mainwindow.h"

#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QPushButton>
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include <QRegularExpression>

// ════════════════════════════════════════════════
//  КОНСТРУКТОР
// ════════════════════════════════════════════════
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Практическая работа 2-2: Собственные классы Qt");
    setMinimumSize(520, 440);

    QTabWidget *tabs = new QTabWidget(this);
    tabs->addTab(buildLoginTab(), "🔐 Задание 1-2: Login");
    tabs->addTab(buildImageTab(), "🖼  Задание 3: Изображение");
    tabs->addTab(buildLedTab(),   "💡 Задание 4: LED");
    setCentralWidget(tabs);
}

// ════════════════════════════════════════════════
//  ЗАДАНИЕ 1+2 — LOGIN + ВАЛИДАЦИЯ
// ════════════════════════════════════════════════
QWidget *MainWindow::buildLoginTab()
{
    QWidget     *w   = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(w);
    lay->setSpacing(12);
    lay->setContentsMargins(24, 24, 24, 24);

    QLabel *title = new QLabel("<b>Форма входа в систему</b>");
    title->setStyleSheet("font-size:15px; color:#1565C0;");

    // Поле имени пользователя
    m_userField = new IconizedLineEdit(w);
    m_userField->setPlaceholderText("Имя пользователя (мин. 3 символа)...");
    m_userField->setIconMode(IconizedLineEdit::ModeValidation);

    // Валидатор: минимум 3 символа, только буквы и цифры
    auto *userVal = new QRegularExpressionValidator(
        QRegularExpression("[A-Za-z0-9]{3,}"), w);
    m_userField->setValidator(userVal);

    // Поле пароля
    m_passField = new IconizedLineEdit(w);
    m_passField->setPlaceholderText("Пароль (мин. 6 символов)...");
    m_passField->setEchoMode(QLineEdit::Password);
    m_passField->setIconMode(IconizedLineEdit::ModeValidation);

    // Валидатор: минимум 6 символов
    auto *passVal = new QRegularExpressionValidator(
        QRegularExpression(".{6,}"), w);
    m_passField->setValidator(passVal);

    QPushButton *btn = new QPushButton("Войти");
    btn->setStyleSheet(
        "padding:8px 24px; font-size:13px;"
        "background:#1565C0; color:white;"
        "border-radius:6px; font-weight:bold;");

    m_loginStatus = new QLabel("", w);
    m_loginStatus->setAlignment(Qt::AlignCenter);
    m_loginStatus->setStyleSheet("font-size:12px;");

    lay->addWidget(title);
    lay->addSpacing(8);
    lay->addWidget(new QLabel("Имя пользователя:"));
    lay->addWidget(m_userField);
    lay->addWidget(new QLabel("Пароль:"));
    lay->addWidget(m_passField);
    lay->addSpacing(8);
    lay->addWidget(btn);
    lay->addWidget(m_loginStatus);
    lay->addStretch();

    connect(btn, &QPushButton::clicked,
            this, &MainWindow::onLoginClicked);

    return w;
}

void MainWindow::onLoginClicked()
{
    QString user = m_userField->text();
    QString pass = m_passField->text();

    if (user.length() < 3) {
        m_loginStatus->setStyleSheet("color:red; font-size:12px;");
        m_loginStatus->setText("❌ Имя пользователя: минимум 3 символа!");
        return;
    }
    if (pass.length() < 6) {
        m_loginStatus->setStyleSheet("color:red; font-size:12px;");
        m_loginStatus->setText("❌ Пароль: минимум 6 символов!");
        return;
    }

    m_loginStatus->setStyleSheet("color:green; font-size:12px;");
    m_loginStatus->setText(
        QString("✅ Вход выполнен! Добро пожаловать, %1!").arg(user));
}

// ════════════════════════════════════════════════
//  ЗАДАНИЕ 3 — ПРОСМОТР ИЗОБРАЖЕНИЯ
// ════════════════════════════════════════════════
QWidget *MainWindow::buildImageTab()
{
    QWidget     *w   = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(w);
    lay->setSpacing(10);
    lay->setContentsMargins(24, 24, 24, 24);

    QLabel *title = new QLabel("<b>Просмотр изображения</b>");
    title->setStyleSheet("font-size:15px; color:#1565C0;");

    // Поле пути с иконкой-кнопкой выбора файла
    m_pathField = new IconizedLineEdit(w);
    m_pathField->setPlaceholderText("Путь к изображению...");
    m_pathField->setIconMode(IconizedLineEdit::ModeFile);

    QPushButton *btnLoad = new QPushButton("Загрузить изображение");
    btnLoad->setStyleSheet(
        "padding:6px 20px; font-size:12px;"
        "background:#1565C0; color:white;"
        "border-radius:6px;");

    // Область отображения изображения
    m_imageLabel = new QLabel(w);
    m_imageLabel->setAlignment(Qt::AlignCenter);
    m_imageLabel->setMinimumHeight(220);
    m_imageLabel->setStyleSheet(
        "border:2px dashed #BBDEFB;"
        "background:#F8F9FA; color:#999;");
    m_imageLabel->setText("[ Изображение не загружено ]");

    lay->addWidget(title);
    lay->addWidget(new QLabel("Путь к файлу (нажмите 📂 для выбора):"));
    lay->addWidget(m_pathField);
    lay->addWidget(btnLoad);
    lay->addWidget(m_imageLabel);

    connect(m_pathField, &IconizedLineEdit::iconClicked,
            this, &MainWindow::onChooseFile);
    connect(btnLoad, &QPushButton::clicked,
            this, &MainWindow::onLoadImage);

    return w;
}

void MainWindow::onChooseFile()
{
    QString path = QFileDialog::getOpenFileName(
        this, "Выбрать изображение", "",
        "Изображения (*.png *.jpg *.jpeg *.bmp *.gif)");
    if (!path.isEmpty()) {
        m_pathField->setText(path);
        onLoadImage();
    }
}

void MainWindow::onLoadImage()
{
    QString path = m_pathField->text();
    if (path.isEmpty()) {
        QMessageBox::warning(this, "Предупреждение",
            "Укажите путь к изображению!");
        return;
    }

    QPixmap pix(path);
    if (pix.isNull()) {
        m_imageLabel->setText("❌ Не удалось загрузить изображение!");
        return;
    }

    m_imageLabel->setPixmap(
        pix.scaled(m_imageLabel->size(),
                   Qt::KeepAspectRatio,
                   Qt::SmoothTransformation));
}

// ════════════════════════════════════════════════
//  ЗАДАНИЕ 4 — LED INDICATOR (3 состояния)
// ════════════════════════════════════════════════
QWidget *MainWindow::buildLedTab()
{
    QWidget     *w   = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(w);
    lay->setSpacing(16);
    lay->setContentsMargins(24, 24, 24, 24);

    QLabel *title = new QLabel(
        "<b>Светодиодный индикатор — 3 состояния</b>");
    title->setStyleSheet("font-size:15px; color:#1565C0;");

    // LED индикатор
    m_led = new LedIndicator(w);
    m_led->setTristate(true);

    m_ledStatus = new QLabel("Состояние: ⚫ OFF", w);
    m_ledStatus->setStyleSheet("font-size:13px;");
    m_ledStatus->setAlignment(Qt::AlignCenter);

    QLabel *info = new QLabel(
        "Нажмите на индикатор для смены состояния:\n"
        "OFF  →  ON  →  ПРОМЕЖУТОЧНОЕ  →  OFF", w);
    info->setStyleSheet("color:#777; font-size:11px;");
    info->setAlignment(Qt::AlignCenter);

    // Кнопки ручного управления
    QPushButton *btnOff  = new QPushButton("Set OFF");
    QPushButton *btnOn   = new QPushButton("Set ON");
    QPushButton *btnMid  = new QPushButton("Set ПРОМЕЖУТОЧНОЕ");

    btnOff->setStyleSheet(
        "padding:6px 16px; background:#555;"
        "color:white; border-radius:4px;");
    btnOn->setStyleSheet(
        "padding:6px 16px; background:#2E7D32;"
        "color:white; border-radius:4px;");
    btnMid->setStyleSheet(
        "padding:6px 16px; background:#E65100;"
        "color:white; border-radius:4px;");

    QHBoxLayout *btnRow = new QHBoxLayout;
    btnRow->addWidget(btnOff);
    btnRow->addWidget(btnOn);
    btnRow->addWidget(btnMid);

    lay->addWidget(title);
    lay->addWidget(m_led, 0, Qt::AlignCenter);
    lay->addWidget(m_ledStatus);
    lay->addWidget(info);
    lay->addLayout(btnRow);
    lay->addStretch();

    connect(m_led, &LedIndicator::stateChanged,
            this,  &MainWindow::onLedStateChanged);

    connect(btnOff,  &QPushButton::clicked,
            [this]() { m_led->setState(LedIndicator::Off); });
    connect(btnOn,   &QPushButton::clicked,
            [this]() { m_led->setState(LedIndicator::On); });
    connect(btnMid,  &QPushButton::clicked,
            [this]() { m_led->setState(LedIndicator::Intermediate); });

    return w;
}

void MainWindow::onLedStateChanged(LedIndicator::State state)
{
    switch (state) {
        case LedIndicator::Off:
            m_ledStatus->setStyleSheet("color:#555; font-size:13px;");
            m_ledStatus->setText("Состояние: ⚫ OFF — выключен");
            break;
        case LedIndicator::On:
            m_ledStatus->setStyleSheet("color:green; font-size:13px;");
            m_ledStatus->setText("Состояние: 🟢 ON — включён");
            break;
        case LedIndicator::Intermediate:
            m_ledStatus->setStyleSheet("color:orange; font-size:13px;");
            m_ledStatus->setText("Состояние: 🟡 ПРОМЕЖУТОЧНОЕ");
            break;
    }
}
