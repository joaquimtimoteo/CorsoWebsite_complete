#include "ledindicator.h"
#include <QPainter>
#include <QRadialGradient>

LedIndicator::LedIndicator(QWidget *parent)
    : QWidget(parent)
    , m_state(Off)
    , m_tristate(false)
{
    setFixedSize(32, 32);
    setCursor(Qt::PointingHandCursor);
}

void LedIndicator::setTristate(bool enable)
{
    m_tristate = enable;
}

void LedIndicator::setState(State state)
{
    if (!m_tristate && state == Intermediate)
        return;
    m_state = state;
    update();
    emit stateChanged(m_state);
}

LedIndicator::State LedIndicator::state() const
{
    return m_state;
}

QSize LedIndicator::sizeHint() const
{
    return QSize(32, 32);
}

void LedIndicator::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    QColor color;
    switch (m_state) {
        case Off:          color = QColor(80, 80, 80);   break;
        case On:           color = QColor(50, 200, 50);  break;
        case Intermediate: color = QColor(255, 165, 0);  break;
    }

    // Тень
    p.setBrush(color.darker(150));
    p.setPen(Qt::NoPen);
    p.drawEllipse(2, 2, 28, 28);

    // LED с градиентом
    QRadialGradient grad(12, 10, 14);
    grad.setColorAt(0, color.lighter(160));
    grad.setColorAt(1, color.darker(120));
    p.setBrush(grad);
    p.setPen(QPen(color.darker(180), 1));
    p.drawEllipse(3, 3, 26, 26);

    // Блик
    p.setBrush(QColor(255, 255, 255, 80));
    p.setPen(Qt::NoPen);
    p.drawEllipse(8, 6, 10, 8);
}

void LedIndicator::mousePressEvent(QMouseEvent *)
{
    if (m_tristate) {
        switch (m_state) {
            case Off:          setState(On);           break;
            case On:           setState(Intermediate); break;
            case Intermediate: setState(Off);          break;
        }
    } else {
        setState(m_state == Off ? On : Off);
    }
}
