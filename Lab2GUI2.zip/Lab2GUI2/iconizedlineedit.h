#ifndef ICONIZEDLINEEDIT_H
#define ICONIZEDLINEEDIT_H

#include <QWidget>
#include <QLineEdit>
#include <QLabel>
#include <QHBoxLayout>
#include <QValidator>

class IconizedLineEdit : public QWidget
{
    Q_OBJECT

public:
    enum IconMode {
        ModeStatic,      // иконка фиксированная
        ModeValidation,  // иконка меняется по валидации
        ModeFile         // клик открывает диалог файла
    };

    explicit IconizedLineEdit(QWidget *parent = nullptr);

    QString text() const;
    void setText(const QString &text);
    void setPlaceholderText(const QString &text);
    void setEchoMode(QLineEdit::EchoMode mode);
    void setValidator(const QValidator *validator);
    void setIconMode(IconMode mode);
    void setStaticIcon(const QString &icon);

signals:
    void textChanged(const QString &text);
    void iconClicked();

private slots:
    void onTextChanged(const QString &text);
    void onIconClicked();

private:
    QLineEdit   *m_lineEdit;
    QLabel      *m_iconLabel;
    QHBoxLayout *m_layout;
    IconMode     m_mode;

    void updateIcon(const QString &text);
};

#endif
