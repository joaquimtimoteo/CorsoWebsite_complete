#ifndef LEDINDICATOR_H
#define LEDINDICATOR_H

#include <QWidget>

class LedIndicator : public QWidget
{
    Q_OBJECT

public:
    enum State {
        Off,
        On,
        Intermediate
    };

    explicit LedIndicator(QWidget *parent = nullptr);

    void  setTristate(bool enable);
    void  setState(State state);
    State state() const;

    QSize sizeHint() const override;

signals:
    void stateChanged(State state);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;

private:
    State m_state;
    bool  m_tristate;
};

#endif
