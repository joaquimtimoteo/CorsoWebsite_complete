#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QSlider>
#include <QScrollBar>
#include <QSpinBox>
#include <QCheckBox>
#include <QLineEdit>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void onCellClicked(int id);
    void onClearClicked();

private:
    // Задание 2 — игровое поле
    QPushButton *buttons[3][3];
    QLabel      *statusLabel;
    int          currentPlayer;
    int          startPlayer;

    bool    checkWinner();
    void    resetBoard();
    void    updateLabel();
    QWidget *buildWidgetsTab();
    QWidget *buildGameTab();
};

#endif
