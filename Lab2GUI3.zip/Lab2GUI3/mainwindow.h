#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPlainTextEdit>
#include <QSlider>
#include <QScrollBar>
#include <QSpinBox>
#include <QCheckBox>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

protected:
    void closeEvent(QCloseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private slots:
    // Задание 1 — позиция курсора
    void onCursorChanged();

    // Задание 2 — настройки
    void openSettings();

    // Задание 3 — CheckBox
    void onCheckBoxToggled(bool checked);

    // Задание 5 — загрузка файла
    void loadAndDraw();

private:
    // Задание 1
    QPlainTextEdit *textEditor;
    QLabel         *cursorLabel;

    // Задание 3 — виджеты
    QSlider    *slider;
    QScrollBar *scrollBar;
    QSpinBox   *spinBox;
    QCheckBox  *checkBox;
    QLabel     *statusLbl;

    // Задание 5/6 — график
    QLabel          *canvas;
    QVector<double>  m_xData;
    QVector<double>  m_yData;

    void buildUI();
    void buildMenu();
    void drawGraph();
};

#endif
