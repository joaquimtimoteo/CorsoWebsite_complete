#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QSlider>
#include <QScrollBar>
#include <QSpinBox>
#include <QCheckBox>
#include <QLineEdit>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Задание 1
    void onCheckBoxToggled(bool checked);

    // Задание 2 — Крестики-нолики
    void onCellClicked(int id);
    void onClearClicked();

private:
    Ui::MainWindow *ui;

    // Задание 2 — игровое поле
    QPushButton *buttons[3][3];
    QLabel      *statusLabel;
    int          currentPlayer;
    int          startPlayer;

    bool checkWinner();
    void resetBoard();
    void updateLabel();

    QWidget *buildWidgetsTab();
    QWidget *buildGameTab();
};

#endif
