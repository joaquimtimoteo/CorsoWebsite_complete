#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QFrame>
#include <QMessageBox>

// ════════════════════════════════════════════════
//  КОНСТРУКТОР
// ════════════════════════════════════════════════
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , currentPlayer(1)
    , startPlayer(1)
{
    ui->setupUi(this);
    setWindowTitle("Практическая работа 2-1: Виджеты и Крестики-нолики");
    setMinimumSize(540, 500);

    // Вкладки
    QTabWidget *tabs = new QTabWidget(this);
    tabs->addTab(buildWidgetsTab(), "⚙  Задание 1 — Виджеты");
    tabs->addTab(buildGameTab(),    "✖  Задание 2 — Крестики-нолики");
    setCentralWidget(tabs);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ════════════════════════════════════════════════
//  ЗАДАНИЕ 1 — 5 ВИДЖЕТОВ С СИГНАЛАМИ И СЛОТАМИ
// ════════════════════════════════════════════════
QWidget *MainWindow::buildWidgetsTab()
{
    QWidget     *w   = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(w);
    lay->setSpacing(16);
    lay->setContentsMargins(20, 20, 20, 20);

    // Заголовок
    QLabel *title = new QLabel(
        "<b>Сигнально-слотовые соединения между виджетами</b>");
    title->setStyleSheet("font-size:14px; color:#1565C0;");
    lay->addWidget(title);

    // ── Группа 1: QSlider ↔ QScrollBar ↔ QSpinBox ──
    QGroupBox   *grp1  = new QGroupBox(
        "Виджет 1-3: QSlider — QScrollBar — QSpinBox");
    QVBoxLayout *layG1 = new QVBoxLayout(grp1);

    QSlider    *slider    = new QSlider(Qt::Horizontal);
    QScrollBar *scrollBar = new QScrollBar(Qt::Horizontal);
    QSpinBox   *spinBox   = new QSpinBox;

    slider->setRange(0, 100);
    scrollBar->setRange(0, 100);
    spinBox->setRange(0, 100);
    slider->setFixedHeight(30);
    scrollBar->setFixedHeight(20);

    QHBoxLayout *rowSpin = new QHBoxLayout;
    rowSpin->addWidget(new QLabel("QSpinBox:"));
    rowSpin->addWidget(spinBox);
    rowSpin->addStretch();

    layG1->addWidget(new QLabel("QSlider:"));
    layG1->addWidget(slider);
    layG1->addWidget(new QLabel("QScrollBar (следует за слайдером):"));
    layG1->addWidget(scrollBar);
    layG1->addLayout(rowSpin);

    // Соединения сигнал → слот
    connect(slider,
            QOverload<int>::of(&QSlider::valueChanged),
            scrollBar, &QScrollBar::setValue);

    connect(slider,
            QOverload<int>::of(&QSlider::valueChanged),
            spinBox,   &QSpinBox::setValue);

    connect(spinBox,
            QOverload<int>::of(&QSpinBox::valueChanged),
            slider,    &QSlider::setValue);

    lay->addWidget(grp1);

    // ── Группа 2: QCheckBox → QLabel ──
    QGroupBox   *grp2     = new QGroupBox(
        "Виджет 4-5: QCheckBox — QLabel");
    QHBoxLayout *layG2    = new QHBoxLayout(grp2);
    QCheckBox   *checkBox = new QCheckBox("Активировать");
    QLabel      *chkLabel = new QLabel("Статус: Выкл");
    chkLabel->setStyleSheet("color:red; font-weight:bold;");

    layG2->addWidget(checkBox);
    layG2->addWidget(chkLabel);
    layG2->addStretch();

    connect(checkBox, &QCheckBox::toggled,
            [chkLabel](bool checked) {
                if (checked) {
                    chkLabel->setText("Статус: Вкл  ✓");
                    chkLabel->setStyleSheet(
                        "color:green; font-weight:bold;");
                } else {
                    chkLabel->setText("Статус: Выкл");
                    chkLabel->setStyleSheet(
                        "color:red; font-weight:bold;");
                }
            });

    lay->addWidget(grp2);

    // ── Группа 3: QPushButton → QLineEdit.clear() ──
    QGroupBox   *grp3    = new QGroupBox(
        "Виджет 5: QPushButton — QLineEdit (очистка)");
    QHBoxLayout *layG3   = new QHBoxLayout(grp3);
    QLineEdit   *lineEdit = new QLineEdit;
    QPushButton *clearBtn = new QPushButton("Очистить");

    lineEdit->setPlaceholderText("Введите текст...");
    clearBtn->setStyleSheet("padding:4px 14px;");

    layG3->addWidget(lineEdit);
    layG3->addWidget(clearBtn);

    connect(clearBtn, &QPushButton::clicked,
            lineEdit,  &QLineEdit::clear);

    lay->addWidget(grp3);
    lay->addStretch();

    return w;
}

void MainWindow::onCheckBoxToggled(bool /*checked*/) {}

// ════════════════════════════════════════════════
//  ЗАДАНИЕ 2 — КРЕСТИКИ-НОЛИКИ
// ════════════════════════════════════════════════
QWidget *MainWindow::buildGameTab()
{
    QWidget     *w   = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(w);
    lay->setSpacing(12);
    lay->setContentsMargins(20, 20, 20, 20);

    // ── Метка текущего игрока ──
    statusLabel = new QLabel;
    statusLabel->setAlignment(Qt::AlignCenter);
    statusLabel->setStyleSheet(
        "font-size:16px; font-weight:bold;"
        "padding:8px; border-radius:6px;"
        "background:#E3F2FD; color:#1565C0;");
    updateLabel();
    lay->addWidget(statusLabel);

    // ── Сетка кнопок 3×3 ──
    QFrame      *frame  = new QFrame;
    QGridLayout *grid   = new QGridLayout(frame);
    grid->setSpacing(6);

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            buttons[i][j] = new QPushButton;
            buttons[i][j]->setFixedSize(90, 90);
            buttons[i][j]->setStyleSheet(
                "font-size:28px; font-weight:bold;"
                "background:white;"
                "border:2px solid #BBDEFB;"
                "border-radius:8px;");
            grid->addWidget(buttons[i][j], i, j);

            // ✅ Lambda вместо QSignalMapper
            int id = i * 3 + j;
            connect(buttons[i][j], &QPushButton::clicked,
                    [this, id]() {
                        onCellClicked(id);
                    });
        }
    }

    lay->addWidget(frame, 0, Qt::AlignCenter);

    // ── Кнопка Clear ──
    QPushButton *clearBtn = new QPushButton("🔄  Clear — сброс поля");
    clearBtn->setFixedHeight(42);
    clearBtn->setStyleSheet(
        "font-size:13px; font-weight:bold;"
        "background:#EF5350; color:white;"
        "border-radius:8px; padding:0 20px;");
    lay->addWidget(clearBtn);
    lay->addStretch();

    connect(clearBtn, &QPushButton::clicked,
            this,     &MainWindow::onClearClicked);

    return w;
}

// ────────────────────────────────────────────────
//  Обработчик нажатия ячейки
// ────────────────────────────────────────────────
void MainWindow::onCellClicked(int id)
{
    int row = id / 3;
    int col = id % 3;

    // Ячейка занята — игнорируем
    if (!buttons[row][col]->text().isEmpty())
        return;

    // Ставим символ текущего игрока
    if (currentPlayer == 1) {
        buttons[row][col]->setText("X");
        buttons[row][col]->setStyleSheet(
            "font-size:28px; font-weight:bold;"
            "background:#E3F2FD; color:#1565C0;"
            "border:2px solid #1565C0;"
            "border-radius:8px;");
    } else {
        buttons[row][col]->setText("O");
        buttons[row][col]->setStyleSheet(
            "font-size:28px; font-weight:bold;"
            "background:#FFEBEE; color:#C62828;"
            "border:2px solid #C62828;"
            "border-radius:8px;");
    }

    // Проверяем победителя
    if (checkWinner()) {
        QMessageBox::information(this, "Победа! 🎉",
            QString("Победил Player %1!").arg(currentPlayer));
        resetBoard();
        return;
    }

    // Проверяем ничью
    bool full = true;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (buttons[i][j]->text().isEmpty())
                full = false;

    if (full) {
        QMessageBox::information(this, "Ничья! 🤝",
            "Ничья! Никто не победил.");
        resetBoard();
        return;
    }

    // Передаём ход
    currentPlayer = (currentPlayer == 1) ? 2 : 1;
    updateLabel();
}

// ────────────────────────────────────────────────
//  Кнопка Clear — сброс поля
// ────────────────────────────────────────────────
void MainWindow::onClearClicked()
{
    startPlayer   = (startPlayer == 1) ? 2 : 1;
    currentPlayer = startPlayer;
    resetBoard();
}

// ────────────────────────────────────────────────
//  Проверка победителя
// ────────────────────────────────────────────────
bool MainWindow::checkWinner()
{
    // Строки
    for (int i = 0; i < 3; i++) {
        if (!buttons[i][0]->text().isEmpty() &&
            buttons[i][0]->text() == buttons[i][1]->text() &&
            buttons[i][1]->text() == buttons[i][2]->text())
            return true;
    }
    // Столбцы
    for (int j = 0; j < 3; j++) {
        if (!buttons[0][j]->text().isEmpty() &&
            buttons[0][j]->text() == buttons[1][j]->text() &&
            buttons[1][j]->text() == buttons[2][j]->text())
            return true;
    }
    // Главная диагональ
    if (!buttons[0][0]->text().isEmpty() &&
        buttons[0][0]->text() == buttons[1][1]->text() &&
        buttons[1][1]->text() == buttons[2][2]->text())
        return true;
    // Побочная диагональ
    if (!buttons[0][2]->text().isEmpty() &&
        buttons[0][2]->text() == buttons[1][1]->text() &&
        buttons[1][1]->text() == buttons[2][0]->text())
        return true;

    return false;
}

// ────────────────────────────────────────────────
//  Сброс поля
// ────────────────────────────────────────────────
void MainWindow::resetBoard()
{
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            buttons[i][j]->setText("");
            buttons[i][j]->setStyleSheet(
                "font-size:28px; font-weight:bold;"
                "background:white;"
                "border:2px solid #BBDEFB;"
                "border-radius:8px;");
        }
    }
    updateLabel();
}

// ────────────────────────────────────────────────
//  Обновление метки текущего игрока
// ────────────────────────────────────────────────
void MainWindow::updateLabel()
{
    if (currentPlayer == 1) {
        statusLabel->setText("🎮  Ход: Player 1  —  X");
        statusLabel->setStyleSheet(
            "font-size:16px; font-weight:bold;"
            "padding:8px; border-radius:6px;"
            "background:#E3F2FD; color:#1565C0;");
    } else {
        statusLabel->setText("🎮  Ход: Player 2  —  O");
        statusLabel->setStyleSheet(
            "font-size:16px; font-weight:bold;"
            "padding:8px; border-radius:6px;"
            "background:#FFEBEE; color:#C62828;");
    }
}
